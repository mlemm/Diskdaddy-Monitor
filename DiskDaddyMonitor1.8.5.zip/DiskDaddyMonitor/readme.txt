=== Diskdaddy.com Web Monitor ===
Contributors: markuslemm
Tags: feedback, support
Requires at least: 3.7
Tested up to: 4.0.1
Stable tag: 1.8.5
Author URI: http://www.markuslemm.com
License: GPLv3 or later

== Description ==

Readme for Diskdaddy Monitor

This plugin will keep track of :
 Last User to Login with Timestamp
 Last post/page created with url and Timestamp
 The URL of the site
 Wordpress Version
 How many plugins need an update
 When the customers support ends (Timestamp)
 Last time this informtion was uploaded
 Name of file to save info into

All this info will be uploaded to the host computer using a HTML POST using the cURL PHP library.  (The Options menu displays info on cURL compatibilitiy)

This current version is 1.8.5 - Created November 30, 2014

For info on plugin contact info@diskdaddy.com


== Installation ==

1. Upload the plugin to the /wp-content/plugins/DiskDaddyMonitor/ directory
2. Activate in Plugins menu in Wordpress

== Changelog ==

= 1.8.5 =
* This is the first stable release version